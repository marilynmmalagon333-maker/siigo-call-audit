import { GoogleGenAI, Type } from "@google/genai";
import { Metrica } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY! });

const auditorResponseSchema = {
  type: Type.OBJECT,
  properties: {
    resumen: {
      type: Type.OBJECT,
      properties: {
        necesidad: { type: Type.STRING },
        ofrecimiento: { type: Type.STRING },
        acuerdos: { type: Type.STRING },
      },
      required: ["necesidad", "ofrecimiento", "acuerdos"],
    },
    formularioMAC: {
      type: Type.OBJECT,
      properties: {
        metricas: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              titulo: { type: Type.STRING },
              subCategorias: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    sub: { type: Type.STRING },
                    resultado: { type: Type.STRING, enum: ["SI", "NO", "PARCIAL"] },
                    minuto: { type: Type.STRING },
                    evidencia: { type: Type.STRING },
                  },
                  required: ["sub", "resultado", "minuto", "evidencia"],
                },
              },
            },
            required: ["titulo", "subCategorias"],
          },
        },
      },
      required: ["metricas"],
    },
    diagnosticoFinal: {
      type: Type.OBJECT,
      properties: {
        score: { type: Type.NUMBER },
        resultadoGestion: { type: Type.STRING },
        vozCliente: {
          type: Type.OBJECT,
          properties: {
            sentimiento: { type: Type.STRING, enum: ["Satisfecho", "Neutro", "Desconfiado", "Inconforme", "Molesto"] },
            porQue: { type: Type.STRING },
          },
          required: ["sentimiento", "porQue"],
        },
        practicasExitosas: { type: Type.STRING },
        oportunidadesMejora: { type: Type.STRING },
        capsulaWaw: { type: Type.STRING },
      },
      required: ["score", "resultadoGestion", "vozCliente", "practicasExitosas", "oportunidadesMejora", "capsulaWaw"],
    },
  },
  required: ["resumen", "formularioMAC", "diagnosticoFinal"],
};

export type AudioPart = {
  data: string;
  mimeType: string;
};

export async function analizarLlamada(audioParts: AudioPart[], trainingRules: string = "", metrics: Metrica[] = []) {
  const prompt = `Analiza esta llamada, la cual puede estar dividida en varias partes. Actúa como un auditor experto.

    ${trainingRules ? `[REGLAS]\n${trainingRules}\n` : ""}

    [MÉTRICAS A EVALUAR]
    Debes evaluar ESTRICTAMENTE las siguientes métricas y subcategorías:
    ${JSON.stringify(metrics, null, 2)}
    
    [INSTRUCCIONES]
    1. PARA CADA MÉTRICA Y SUBCATEGORÍA:
       - Debes llenar el campo 'resultado' (SI, NO, PARCIAL).
       - Debes llenar el campo 'minuto' con el formato (MM:SS).
       - Debes llenar el campo 'evidencia' estrictamente con lo que dice textualmente el agente o asesor en la llamada para cumplir con esa métrica (la frase exacta pronunciada por él).
       - Si no encuentras evidencia o no se cumple, pon "No detectado".
    2. EN 'practicasExitosas' y 'oportunidadesMejora':
       - EXHAUSTIVIDAD: Debes reportar ABSOLUTAMENTE TODO de forma detallada. Queremos un diagnóstico profundo. En las prácticas exitosas, no te limites, reporta lo máximo posible.
       - Tono: Habla SIEMPRE directamente en segunda persona al agente/asesor (ej: "Marilyn, estuviste...", "Tú lograste...", "Debes mejorar...", "Te recomiendo..."). ¡ES UN REQUISITO OBLIGATORIO: Háblale de TÚ, no le hables en tercera persona como 'El agente' o 'El asesor' o 'Se observa que'. Debe ser feedback directo para él/ella! Entusiasta, cercano, profesional y constructivo. El objetivo es ayudar al asesor a crecer.
       - Formato: Usa emojis (🤩💖, ❤️, 🚀, 💡, 👉).
       - 'practicasExitosas': Debes reportar la mayor cantidad de puntos positivos posibles. Resalta lo bueno con ❤️. Sé SUMAMENTE EXTENSO, sumamente detallado y generoso con el feedback positivo. Menciona múltiples puntos separados (al menos 3 o 4 aciertos bien desarrollados), describiendo detalladamente cada acierto detectado de tono, empatía, escucha activa, manejo de objeciones, agilidad u otro cumplimiento de métricas observados en la llamada, y explicando con precisión el impacto positivo de cada acción.
       - 'oportunidadesMejora': 
          * DEBES SER MUY EXIGENTE. Si falta el PEDIDO DE REFERIDOS (pedir a quién más le puede interesar) o el PRE-CIERRE (validar si el cliente tiene dudas, si vamos por buen camino, etc.), menciónalo obligatoriamente.
          * Reporta cada punto no cumplido de las métricas de forma individual.
          * Usa 🚀 para recomendaciones estratégicas.
          * Usa 💡 para las oportunidades específicas.
          * Usa 👉 para un ejemplo concreto de frase que debiste haber dicho (ej: "Diles algo como: ...").
          * Sé muy detallado explicando el por qué y el impacto de estas mejoras.
    3. EN 'capsulaWaw':
       - Identifica el momento más impactante y positivo de la llamada (el "momento WAW").
       - Describe por qué fue excepcional y cómo transformó la experiencia del cliente o aseguró la venta.
       - ¡Sé muy inspirador!
       - Usa emojis relacionados con celebración (✨, 🏆, 🔥, 👑).
    4. EN 'resumen':
       - Redacta de forma natural, humana y cercana. Evita sonar como un informe generado por IA.
       - En 'ofrecimiento': SÉ EXTREMADAMENTE BREVE, CORTO, SINTÉTICO Y PUNTUAL (ej: "Plan Facturación 24 - 100 facturas - $50.000"). NO uses párrafos largos, explicaciones extensas, ni introducciones; debe ser sumamente resumido y concreto.
    5. TONO Y ESTILO: 
       - No parezcas una IA. Usa un tono profesional pero cercano, como de un Mentor o Coach de Ventas que le está dando feedback cara a cara a un gran amigo (el agente).
       - NUNCA uses "El agente", "El cliente", "El asesor", "Se observa que". Háblale directamente de "tú" al agente (ej: "Marilyn, lograste...", "Debes mejorar...", "Te recomiendo que uses...").
       - Estructura las ideas de forma fluida.
    6. ¡Sé extremadamente específico con ejemplos del audio!`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          ...audioParts.map(part => ({ inlineData: { data: part.data, mimeType: part.mimeType } })),
          { text: prompt }
        ],
      },
      config: { 
        responseMimeType: "application/json",
        responseSchema: auditorResponseSchema
      },
    });

    return JSON.parse(response.text!);
  } catch (error) {
    console.error("Error en analizarLlamada:", error);
    throw error;
  }
}

export async function refinarAuditoria(audioParts: AudioPart[], feedback: string, currentResults: any, trainingRules: string, metrics: Metrica[]) {
  const prompt = `Ajusta la auditoría con este feedback de ajuste: ${feedback}

  ${trainingRules ? `[REGLAS HISTÓRICAS Y ENTRENAMIENTO GUARDADO]\n${trainingRules}\n` : ""}
  
  [MÉTRICAS A EVALUAR]
  Debes evaluar ESTRICTAMENTE las siguientes métricas y subcategorías:
  ${JSON.stringify(metrics, null, 2)}
  
  [INSTRUCCIONES]
  (Mismas instrucciones de exhaustividad, tono humano de Coach y emojis que el análisis inicial...)
  1. PARA CADA MÉTRICA Y SUBCATEGORÍA: Resultado, minuto y evidencia estrictamente exacta del asesor.
  2. Habla SIEMPRE directamente en segunda persona al agente/asesor (ej: "Marilyn, estuviste...", "Tú lograste...", "Debes mejorar...", "Te recomiendo..."). ¡ES UN REQUISITO OBLIGATORIO: Háblale de TÚ, no le hables en tercera persona como 'El agente' o 'El asesor' o 'Se observa que'!
  3. EN 'practicasExitosas' y 'oportunidadesMejora': Reporta la mayor cantidad de puntos de acierto. En 'practicasExitosas', sé SUMAMENTE EXTENSO, detallado y generoso, mencionando múltiples puntos positivos con ejemplos y su correspondiente impacto de coaching.
  4. EN 'resumen': Redacción cercana y en 'ofrecimiento' SÉ EXTREMADAMENTE BREVE, CORTO, SINTÉTICO Y PUNTUAL (ej: "Plan Facturación 24 - 100 facturas - $50.000"). No utilices párrafos.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          ...audioParts.map(part => ({ inlineData: { data: part.data, mimeType: part.mimeType } })),
          { text: prompt }
        ],
      },
      config: { 
        responseMimeType: "application/json",
        responseSchema: auditorResponseSchema
      },
    });

    return JSON.parse(response.text!);
  } catch (error) {
    console.error("Error en refinarAuditoria:", error);
    throw error;
  }
}

export async function consultarLlamada(audioParts: AudioPart[], pregunta: string) {
  const prompt = `¡Hola! Soy 'Tu Auditor Siigo'. Responde a esta pregunta sobre la llamada de forma directa y cercana.
  
  Pregunta: ${pregunta}
  
  Reglas:
  - Incluye siempre el minuto exacto (MM:SS) y la frase textual.
  - Si no está en el audio, dímelo directo.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: {
        parts: [
          ...audioParts.map(part => ({ inlineData: { data: part.data, mimeType: part.mimeType } })),
          { text: prompt }
        ],
      },
    });
    return response.text;
  } catch (error) {
    console.error("Error en consultarLlamada:", error);
    throw error;
  }
}
