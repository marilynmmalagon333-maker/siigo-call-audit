export interface SubCategoria {
  sub: string;
  resultado: "SI" | "NO" | "PARCIAL";
  minuto: string;
  evidencia: string;
}

export interface Metrica {
  titulo: string;
  subCategorias: SubCategoria[];
}
