/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, FormEvent, ChangeEvent, useEffect, useRef } from 'react';
import { analizarLlamada, consultarLlamada, refinarAuditoria, AudioPart } from './services/geminiService';
import { Metrica } from './types';
import { motion } from 'motion/react';
import Markdown from 'react-markdown';
import { Target, Users, LayoutDashboard, BrainCircuit, Sparkles, Trash2, Plus, X } from 'lucide-react';

export default function App() {
  const [files, setFiles] = useState<File[]>([]);
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any>(null);
  const [chatInput, setChatInput] = useState("");
  const [chatHistory, setChatHistory] = useState<{question: string, answer: string}[]>([]);
  const [chatLoading, setChatLoading] = useState(false);
  const [trainingRules, setTrainingRules] = useState("");
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [feedback, setFeedback] = useState("");
  const [refining, setRefining] = useState(false);
  const [metrics, setMetrics] = useState<Metrica[]>([]);

  useEffect(() => {
    try {
      const saved = localStorage.getItem('metrics');
      if (saved) {
        setMetrics(JSON.parse(saved));
      } else {
        const initialMetrics = [
          {
            titulo: "CREAR CONEXIÓN",
            subCategorias: [
              { sub: "Saludo cordial", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Explicación motivo", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Genera confianza", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Escucha activa", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Empatía", resultado: "SI", minuto: "00:00", evidencia: "" }
            ]
          },
          {
            titulo: "OBTENER INFORMACIÓN",
            subCategorias: [
              { sub: "Identifica negocio", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Pregunta proceso actual", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Identifica problemas", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Preguntas abiertas", resultado: "SI", minuto: "00:00", evidencia: "" }
            ]
          },
          {
            titulo: "CREAR EMOCIÓN",
            subCategorias: [
              { sub: "Explica beneficios", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Da ejemplos negocio", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Reduce miedos", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Preguntas precierre", resultado: "SI", minuto: "00:00", evidencia: "" }
            ]
          },
          {
            titulo: "OBTENER EL SI",
            subCategorias: [
              { sub: "Explica oferta", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Menciona precio", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Técnicas cierre", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Concreta venta", resultado: "SI", minuto: "00:00", evidencia: "" }
            ]
          },
          {
            titulo: "ROMPER EL NO",
            subCategorias: [
              { sub: "Maneja objeciones", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Responde dudas", resultado: "SI", minuto: "00:00", evidencia: "" },
              { sub: "Avanza negociación", resultado: "SI", minuto: "00:00", evidencia: "" }
            ]
          }
        ];
        setMetrics(initialMetrics as Metrica[]);
      }
      
      const savedRules = localStorage.getItem('trainingRules');
      if (savedRules) setTrainingRules(savedRules);
    } catch (e) {
      console.error("Error parsing data from localStorage:", e);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('trainingRules', trainingRules);
  }, [trainingRules]);

  useEffect(() => {
    if (metrics.length > 0) {
      localStorage.setItem('metrics', JSON.stringify(metrics));
    }
  }, [metrics]);

  const updateSubCategory = (metricIndex: number, subIndex: number, field: string, value: string) => {
    const updatedMetrics = [...metrics];
    (updatedMetrics[metricIndex].subCategorias[subIndex] as any)[field] = value;
    setMetrics(updatedMetrics);
  };

  const addMetric = () => {
    setMetrics([...metrics, { titulo: "NUEVA MÉTRICA", subCategorias: [{ sub: "Nueva sub-categoría", resultado: "SI", minuto: "00:00", evidencia: "" }] }]);
  };

  const removeMetric = (index: number) => {
    setMetrics(metrics.filter((_, i) => i !== index));
  };

  const addSubCategory = (metricIndex: number) => {
    const updatedMetrics = [...metrics];
    updatedMetrics[metricIndex].subCategorias.push({ sub: "Nueva sub-categoría", resultado: "SI", minuto: "00:00", evidencia: "" });
    setMetrics(updatedMetrics);
  };

  const removeSubCategory = (metricIndex: number, subIndex: number) => {
    const updatedMetrics = [...metrics];
    updatedMetrics[metricIndex].subCategorias = updatedMetrics[metricIndex].subCategorias.filter((_, i) => i !== subIndex);
    setMetrics(updatedMetrics);
  };

  const updateMetricTitle = (metricIndex: number, title: string) => {
    const updatedMetrics = [...metrics];
    updatedMetrics[metricIndex].titulo = title;
    setMetrics(updatedMetrics);
  };

  // Helper to read multiple files as base64
  const getAudioParts = async (filesToProcess: File[]): Promise<AudioPart[]> => {
    const promises = filesToProcess.map(file => {
      return new Promise<AudioPart>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => {
          const result = reader.result as string;
          const base64Data = result.includes(',') ? result.split(',')[1] : result;
          resolve({ data: base64Data, mimeType: file.type });
        };
        reader.onerror = () => reject(new Error(`Error al leer el archivo ${file.name}`));
        reader.readAsDataURL(file);
      });
    });
    return Promise.all(promises);
  };

  const handleFileChange = (e: ChangeEvent<HTMLInputElement>) => {
    const newFiles = Array.from(e.target.files || []);
    if (newFiles.length > 0) {
      setFiles(prev => [...prev, ...newFiles]);
    }
    // Clear input so same file can be added again if needed
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  const handleProcess = async (e: FormEvent) => {
    e.preventDefault();
    if (files.length === 0) return;

    setLoading(true);
    setResults(null); 

    try {
      const audioParts = await getAudioParts(files);

      console.log("Iniciando análisis con", files.length, "partes de audio");
      const startTime = Date.now();

      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error("La auditoría está tardando demasiado. Por favor, intenta con archivos más cortos o vuelve a intentarlo.")), 300000)
      );

      console.log("Llamando a analizarLlamada...");
      const data = await Promise.race([
        analizarLlamada(audioParts, trainingRules, metrics),
        timeoutPromise
      ]);
      console.log("analizarLlamada completado en", (Date.now() - startTime) / 1000, "segundos");

      console.log("Análisis completado exitosamente");
      setResults(data);
    } catch (error) {
      console.error("Error en handleProcess:", error);
      alert(error instanceof Error ? error.message : 'Error procesando el audio. Por favor, intenta de nuevo.');
    } finally {
      setLoading(false);
    }
  };

  const handleRefine = async () => {
    if (!feedback || files.length === 0 || !results) return;
    setRefining(true);
    
    try {
      const audioParts = await getAudioParts(files);
      console.log("Iniciando refinamiento con", files.length, "partes...");

      const timeoutPromise = new Promise((_, reject) =>
        setTimeout(() => reject(new Error("El refinamiento está tardando demasiado. Por favor, intenta de nuevo.")), 300000)
      );

      const data = await Promise.race([
        refinarAuditoria(audioParts, feedback, results, trainingRules, metrics),
        timeoutPromise
      ]);

      console.log("Refinamiento completado exitosamente");
      
      // Update global training rules with this feedback
      const updatedRules = trainingRules + (trainingRules ? "\n" : "") + `- ${feedback}`;
      setTrainingRules(updatedRules);
      
      setResults(data);
      setFeedback("");
      alert("Auditoría refinada. Estos ajustes se aplicarán a todas tus futuras llamadas.");
    } catch (err) {
      console.error("Error en handleRefine:", err);
      alert(err instanceof Error ? err.message : "Error al refinar la auditoría.");
    } finally {
      setRefining(false);
    }
  };

  const handleChat = async () => {
    if (!chatInput || files.length === 0) return;
    setChatLoading(true);
    try {
      const audioParts = await getAudioParts(files);
      const answer = await consultarLlamada(audioParts, chatInput);
      setChatHistory([...chatHistory, {question: chatInput, answer}]);
      setChatInput("");
    } catch (err) {
      console.error(err);
      alert("Error al realizar la consulta.");
    } finally {
      setChatLoading(false);
    }
  };

  const handleTrainingFile = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      setTrainingRules(e.target?.result as string);
    };
    reader.readAsText(file);
  };

  const recalculateScore = (updatedResults: any) => {
    let totalSub = 0;
    let scoreSum = 0;
    
    (updatedResults.formularioMAC?.metricas || []).forEach((m: any) => {
      (m.subCategorias || []).forEach((s: any) => {
        totalSub++;
        if (s.resultado === "SI") {
          scoreSum += 1.0;
        } else if (s.resultado === "PARCIAL") {
          scoreSum += 0.5;
        }
      });
    });
    
    if (totalSub > 0) {
      const newScore = Math.round((scoreSum / totalSub) * 100);
      if (updatedResults.diagnosticoFinal) {
        updatedResults.diagnosticoFinal.score = newScore;
      }
    }
  };

  const handleResultOverride = (mIdx: number, sIdx: number, newResult: "SI" | "NO" | "PARCIAL") => {
    if (!results) return;
    const updated = JSON.parse(JSON.stringify(results));
    
    const m = updated.formularioMAC.metricas[mIdx];
    const s = m.subCategorias[sIdx];
    const oldResult = s.resultado;
    s.resultado = newResult;
    
    // Recalculate score
    recalculateScore(updated);
    
    let ops = updated.diagnosticoFinal.oportunidadesMejora || "";
    let pracs = updated.diagnosticoFinal.practicasExitosas || "";
    
    // Clean up previous manual overrides for this subcategory from observations to avoid duplicate spam
    const cleanedSubName = s.sub.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const searchRegexOps = new RegExp(`\\n?\\s*?💡 Cambio manual:.*?"${cleanedSubName}".*?\\n?`, "gi");
    const searchRegexPracs = new RegExp(`\\n?\\s*?❤️ Cambio manual:.*?"${cleanedSubName}".*?\\n?`, "gi");
    ops = ops.replace(searchRegexOps, "").trim();
    pracs = pracs.replace(searchRegexPracs, "").trim();
    
    if (newResult === "NO" || newResult === "PARCIAL") {
      ops += (ops ? "\n" : "") + `💡 Cambio manual: Calificaste "${s.sub}" como "${newResult}" (era ${oldResult}).`;
    } else if (newResult === "SI") {
      pracs += (pracs ? "\n" : "") + `❤️ Cambio manual: Calificaste "${s.sub}" como "SI" (era ${oldResult}). ¡Felicidades!`;
    }
    
    updated.diagnosticoFinal.oportunidadesMejora = ops;
    updated.diagnosticoFinal.practicasExitosas = pracs;
    
    setResults(updated);
  };

  const handleFieldOverride = (mIdx: number, sIdx: number, field: 'minuto' | 'evidencia', value: string) => {
    if (!results) return;
    const updated = JSON.parse(JSON.stringify(results));
    updated.formularioMAC.metricas[mIdx].subCategorias[sIdx][field] = value;
    setResults(updated);
  };

  const resetApp = () => {
    setFiles([]);
    if (fileInputRef.current) {
      fileInputRef.current.value = "";
    }
    setResults(null);
    setChatHistory([]);
    setChatInput("");
    setFeedback("");
  };

  return (
    <div className="min-h-screen bg-slate-50 p-4 md:p-8 font-sans">
      <div className="max-w-6xl mx-auto space-y-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row justify-between items-center bg-white p-6 rounded-2xl shadow-sm border border-slate-100 gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-emerald-100 rounded-lg text-emerald-600">
              <BrainCircuit size={32} />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-slate-900 tracking-tight">Tu Auditor Siigo</h1>
              <p className="text-xs text-slate-500 font-medium uppercase tracking-widest">Inteligencia de Auditoría y Coaching</p>
            </div>
          </div>
        </div>

        <motion.div 
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="space-y-6"
        >
              <div className="bg-white p-8 rounded-2xl shadow-md space-y-6 border border-slate-100">
                <div className="flex justify-between items-center">
                  <h2 className="text-xl font-bold text-slate-800 flex items-center gap-2">
                    <Target className="text-emerald-500" size={24} />
                    Configuración y Auditoría
                  </h2>
                  {results && (
                    <button onClick={resetApp} className="bg-slate-100 text-slate-600 px-4 py-2 rounded-lg hover:bg-slate-200 text-sm font-medium transition-colors flex items-center gap-2">
                      <Trash2 size={16} />
                      Nueva Auditoría
                    </button>
                  )}
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="border-2 border-dashed border-slate-200 p-6 rounded-xl bg-slate-50/50 hover:bg-slate-50 transition-colors group">
                      <p className="text-sm text-slate-600 mb-3 font-semibold flex items-center gap-2">
                        <Users size={16} className="text-slate-400 group-hover:text-emerald-500" />
                        Subir audios de la llamada
                      </p>
                      <input 
                        ref={fileInputRef} 
                        type="file" 
                        multiple 
                        onChange={handleFileChange} 
                        className="w-full text-sm block cursor-pointer file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-emerald-50 file:text-emerald-700 hover:file:bg-emerald-100 transition-all shadow-sm" 
                        accept="audio/*" 
                      />
                      
                      {files.length > 0 && (
                        <div className="mt-4 space-y-2">
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Archivos seleccionados</p>
                          <div className="max-h-32 overflow-y-auto pr-2 space-y-2">
                            {files.map((f, i) => (
                              <div key={i} className="flex items-center justify-between bg-white px-3 py-2 rounded-lg border border-slate-100 shadow-sm text-xs animate-in fade-in slide-in-from-left-2 transition-all">
                                <span className="truncate flex-1 text-slate-700 font-medium">Parte {i + 1}: {f.name}</span>
                                <button onClick={() => removeFile(i)} className="text-slate-400 hover:text-red-500 ml-2 p-1 rounded-full hover:bg-red-50 transition-colors">
                                  <Trash2 size={14} />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>

                    <div className="bg-emerald-50/30 p-4 rounded-xl border border-emerald-100">
                      <label className="text-sm font-semibold text-emerald-800 flex items-center gap-2 mb-2">
                        <BrainCircuit size={16} />
                        Archivo de entrenamiento (.txt)
                      </label>
                      <input type="file" onChange={handleTrainingFile} accept=".txt" className="text-xs w-full" />
                    </div>

                    <div className="bg-amber-50/40 p-4 rounded-xl border border-amber-100 space-y-2">
                      <label className="text-sm font-semibold text-amber-800 flex items-center gap-2">
                        <Sparkles size={16} className="text-amber-500" />
                        Reglas y Ajustes Guardados
                      </label>
                      <p className="text-[11px] text-amber-900/70">Estas reglas se han acumulado de tus ajustes y refinamientos, y se aplicarán a todas las evaluaciones futuras de llamadas.</p>
                      <textarea
                        value={trainingRules}
                        onChange={(e) => setTrainingRules(e.target.value)}
                        className="w-full text-xs p-2 bg-white rounded-lg border border-amber-200 focus:outline-none focus:ring-2 focus:ring-amber-500 text-slate-700 font-mono"
                        placeholder="Sin reglas guardadas aún. Se añadirán automáticamente cuando refines una auditoría, o puedes escribirlas tú directamente."
                        rows={4}
                      />
                      {trainingRules && (
                        <button 
                          onClick={() => {
                            if (window.confirm("¿Estás seguro de que deseas limpiar todas las reglas guardadas?")) {
                              setTrainingRules("");
                            }
                          }}
                          className="text-[10px] text-red-600 hover:text-red-800 font-bold transition-colors flex items-center gap-1"
                        >
                          Limpiar reglas guardadas
                        </button>
                      )}
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex justify-between items-center px-1">
                      <label className="text-sm font-bold text-slate-700 uppercase tracking-tight">Métricas de evaluación</label>
                      <button 
                        onClick={addMetric}
                        className="flex items-center gap-1 bg-emerald-50 text-emerald-700 text-[10px] font-bold px-3 py-1.5 rounded-full hover:bg-emerald-100 transition-colors"
                      >
                        <Plus size={12} />
                        Añadir Métrica
                      </button>
                    </div>
                    
                    <div className="space-y-4 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
                      {metrics.map((m, mIdx) => (
                        <div key={mIdx} className="border border-slate-100 p-4 rounded-2xl bg-white shadow-sm space-y-3 relative group/card">
                          <div className="flex gap-2 items-center">
                            <input 
                              type="text" 
                              value={m.titulo} 
                              onChange={(e) => updateMetricTitle(mIdx, e.target.value)} 
                              className="font-bold text-sm flex-1 p-2 bg-slate-50 border-none rounded-xl focus:ring-2 focus:ring-emerald-500 transition-all" 
                            />
                            <div className="flex gap-1 opacity-0 group-hover/card:opacity-100 transition-opacity">
                              <button onClick={() => addSubCategory(mIdx)} className="p-2 text-emerald-600 hover:bg-emerald-50 rounded-lg transition-colors" title="Añadir sub-categoría">
                                <Plus size={16} />
                              </button>
                              <button onClick={() => removeMetric(mIdx)} className="p-2 text-red-400 hover:bg-red-50 rounded-lg transition-colors" title="Eliminar métrica">
                                <Trash2 size={16} />
                              </button>
                            </div>
                          </div>
                          
                          <div className="space-y-2">
                            { (m.subCategorias || []).map((s, sIdx) => (
                              <div key={sIdx} className="flex gap-2 items-center bg-slate-50/50 p-2 rounded-xl border border-slate-100/50 hover:border-emerald-100 transition-all">
                                <input 
                                  type="text" 
                                  value={s.sub} 
                                  onChange={(e) => updateSubCategory(mIdx, sIdx, 'sub', e.target.value)} 
                                  className="text-[11px] flex-1 bg-transparent border-none focus:ring-0 p-0 font-medium text-slate-700" 
                                />
                                <div className="flex gap-2 items-center">
                                  <select 
                                    value={s.resultado} 
                                    onChange={(e) => updateSubCategory(mIdx, sIdx, 'resultado', e.target.value)} 
                                    className="text-[10px] py-0.5 px-2 bg-white border border-slate-200 rounded-md font-bold text-slate-600"
                                  >
                                    <option value="SI">SI</option>
                                    <option value="NO">NO</option>
                                    <option value="PARCIAL">PARCIAL</option>
                                  </select>
                                  <input 
                                    type="text" 
                                    value={s.minuto} 
                                    onChange={(e) => updateSubCategory(mIdx, sIdx, 'minuto', e.target.value)} 
                                    className="text-[10px] w-12 py-0.5 bg-white border border-slate-200 rounded-md text-center" 
                                    placeholder="MM:SS" 
                                  />
                                  <button onClick={() => removeSubCategory(mIdx, sIdx)} className="text-slate-300 hover:text-red-500 p-1">
                                    <X size={12} />
                                  </button>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <button 
                    onClick={handleProcess} 
                    disabled={loading || files.length === 0} 
                    className={`w-full p-4 rounded-2xl font-bold text-white shadow-lg transition-all flex items-center justify-center gap-3 ${loading || files.length === 0 ? 'bg-slate-300 cursor-not-allowed shadow-none' : 'bg-emerald-600 hover:bg-emerald-700 hover:-translate-y-0.5 active:translate-y-0 shadow-emerald-200'}`}
                  >
                    {loading ? (
                      <>
                        <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1, ease: 'linear' }} className="w-5 h-5 border-2 border-white border-t-transparent rounded-full" />
                        Procesando auditoría...
                      </>
                    ) : (
                      <>
                        <BrainCircuit size={20} />
                        GENERAR AUDITORÍA INTELIGENTE
                      </>
                    )}
                  </button>
                </div>
              </div>

              {results && (
                <div className="space-y-8 mt-8 pb-12">
                  <div className="flex flex-col gap-6">
                    <h2 className="font-bold text-2xl text-slate-800 border-l-4 border-emerald-500 pl-4 tracking-tight">Formulario de Auditoría (MAC)</h2>
                    
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                      {(results.formularioMAC?.metricas || []).map((m: any, mIdx: number) => (
                        <div key={mIdx} className="bg-white border border-slate-100 rounded-2xl p-6 shadow-sm hover:shadow-md transition-shadow group/table">
                          <h3 className="font-bold text-lg mb-4 text-slate-900 group-hover/table:text-emerald-700 transition-colors uppercase tracking-tight">{m.titulo}</h3>
                          <div className="overflow-hidden rounded-xl border border-slate-100">
                            <table className="w-full text-left text-sm">
                              <thead>
                                <tr className="bg-slate-50 text-slate-500 uppercase text-[10px] font-bold">
                                  <th className="px-4 py-3">Sub-categoría</th>
                                  <th className="px-4 py-3 text-center">Res</th>
                                  <th className="px-4 py-3 text-center">Min</th>
                                  <th className="px-4 py-3">Evidencia</th>
                                </tr>
                              </thead>
                              <tbody className="divide-y divide-slate-100">
                                {(m.subCategorias || []).map((s: any, sIdx: number) => (
                                  <tr key={sIdx} className="hover:bg-slate-50/50 transition-colors">
                                    <td className="px-4 py-3 font-medium text-slate-700 text-xs">{s.sub}</td>
                                    <td className="px-4 py-3 text-center">
                                      <select
                                        value={s.resultado}
                                        onChange={(e) => handleResultOverride(mIdx, sIdx, e.target.value as any)}
                                        className={`px-2 py-1 rounded-full text-[10px] font-bold border border-slate-200 cursor-pointer focus:ring-2 focus:ring-emerald-500 focus:outline-none transition-all ${
                                          s.resultado === 'SI' ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 
                                          s.resultado === 'NO' ? 'bg-red-50 text-red-700 border-red-200' : 
                                          'bg-yellow-50 text-yellow-700 border-yellow-200'
                                        }`}
                                      >
                                        <option value="SI">SI</option>
                                        <option value="NO">NO</option>
                                        <option value="PARCIAL">PARCIAL</option>
                                      </select>
                                    </td>
                                    <td className="px-4 py-3 text-center">
                                      <input
                                        type="text"
                                        value={s.minuto}
                                        onChange={(e) => handleFieldOverride(mIdx, sIdx, 'minuto', e.target.value)}
                                        className="text-center text-slate-600 font-mono text-[10px] w-14 bg-transparent border-b border-dashed border-slate-200 focus:border-emerald-500 focus:ring-0 p-0 text-center uppercase"
                                        placeholder="MM:SS"
                                      />
                                    </td>
                                    <td className="px-4 py-3 text-xs text-slate-800 italic bg-emerald-50/10">
                                      <input
                                        type="text"
                                        value={s.evidencia}
                                        onChange={(e) => handleFieldOverride(mIdx, sIdx, 'evidencia', e.target.value)}
                                        className="w-full text-xs text-slate-800 bg-transparent border-none focus:bg-white focus:ring-1 focus:ring-emerald-500 p-1 rounded font-medium focus:outline-none"
                                        placeholder="No detectado"
                                        title="Haz clic para editar la evidencia"
                                      />
                                    </td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-slate-900 text-white p-6 rounded-2xl shadow-xl space-y-4 relative overflow-hidden">
                    <div className="absolute top-0 right-0 w-48 h-48 bg-emerald-500/10 rounded-full blur-3xl -mr-24 -mt-24"></div>
                    
                    <div className="relative">
                      <div className="flex justify-between items-center mb-4">
                        <h2 className="font-bold text-lg flex items-center gap-2">
                          <Sparkles className="text-emerald-400" size={20} />
                          LO QUE DEBES SABER
                        </h2>
                      </div>
                      
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div className="p-3 bg-white/5 rounded-xl border border-white/10 backdrop-blur-sm text-center">
                          <p className="text-emerald-400 text-[10px] font-bold uppercase tracking-widest mb-0.5">Calificación</p>
                          <p className="text-2xl font-bold">{results.diagnosticoFinal?.score || '0'}%</p>
                        </div>
                        <div className="md:col-span-2 p-3 bg-white/5 rounded-xl border border-white/10 backdrop-blur-sm flex items-center">
                          <div>
                            <p className="text-emerald-400 text-[10px] font-bold uppercase tracking-widest mb-0.5">Resumen de Gestión</p>
                            <p className="text-sm font-semibold">{results.diagnosticoFinal?.resultadoGestion || 'N/A'}</p>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 space-y-4">
                        <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                          <h3 className="font-bold text-emerald-400 text-[10px] uppercase tracking-wider mb-2 flex items-center gap-2">
                             💖 Prácticas Exitosas
                          </h3>
                          <p className="text-slate-300 leading-snug text-xs whitespace-pre-line line-clamp-4 hover:line-clamp-none transition-all">{results.diagnosticoFinal?.practicasExitosas}</p>
                        </div>

                        <div className="p-4 bg-white/5 rounded-xl border border-white/10">
                          <h3 className="font-bold text-blue-400 text-[10px] uppercase tracking-wider mb-2 flex items-center gap-2">
                            🚀 Mejora
                          </h3>
                          <p className="text-slate-300 leading-snug text-xs whitespace-pre-line line-clamp-4 hover:line-clamp-none transition-all">{results.diagnosticoFinal?.oportunidadesMejora}</p>
                        </div>
                      </div>

                      {results.diagnosticoFinal?.capsulaWaw && (
                        <motion.div 
                          initial={{ scale: 0.98, opacity: 0 }}
                          animate={{ scale: 1, opacity: 1 }}
                          className="mt-4 p-4 bg-gradient-to-br from-emerald-500 to-teal-600 rounded-2xl shadow-lg"
                        >
                          <h3 className="font-black text-white flex items-center justify-center gap-2 mb-2 text-center text-xs">
                            <Sparkles size={16} />
                            ¡MOMENTO WAW!
                            <Sparkles size={16} />
                          </h3>
                          <p className="text-white text-center italic font-bold text-sm leading-tight">
                            "{results.diagnosticoFinal.capsulaWaw}"
                          </p>
                        </motion.div>
                      )}
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4">
                      <h2 className="font-bold text-xl text-slate-800 flex items-center gap-2">
                        <Users className="text-emerald-500" size={20} />
                        Voz del Cliente
                      </h2>
                      <div className="p-4 bg-slate-50 rounded-xl space-y-2">
                        <div className="flex items-center gap-2">
                          <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                            results.diagnosticoFinal?.vozCliente?.sentimiento === 'Satisfecho' ? 'bg-emerald-100 text-emerald-700' :
                            results.diagnosticoFinal?.vozCliente?.sentimiento === 'Molesto' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
                          }`}>
                            {results.diagnosticoFinal?.vozCliente?.sentimiento}
                          </span>
                        </div>
                        <p className="text-sm text-slate-600 italic font-medium leading-relaxed">
                          "{results.diagnosticoFinal?.vozCliente?.porQue}"
                        </p>
                      </div>
                    </div>

                    <div className="bg-white p-6 rounded-2xl border border-slate-100 shadow-sm space-y-4">
                      <h2 className="font-bold text-xl text-slate-800 flex items-center gap-2">
                        <LayoutDashboard className="text-blue-500" size={20} />
                        Lo que escuché
                      </h2>
                      <div className="space-y-4 text-sm">
                        <div>
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Lo que el cliente buscaba</p>
                          <p className="text-slate-700 leading-relaxed">{results.resumen?.necesidad}</p>
                        </div>
                        <div>
                          <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Resumen del ofrecimiento</p>
                          <p className="text-slate-700 leading-relaxed font-medium">{results.resumen?.ofrecimiento}</p>
                        </div>
                        <div className="p-3 bg-blue-50 rounded-xl border border-blue-100">
                          <p className="text-[10px] font-bold text-blue-600 uppercase tracking-widest mb-1">🤝 En qué quedaron</p>
                          <p className="text-blue-900 font-bold">{results.resumen?.acuerdos}</p>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-600 p-8 rounded-3xl shadow-xl shadow-blue-200 text-white space-y-4">
                    <h2 className="font-bold text-xl flex items-center gap-2">
                      <Sparkles size={24} />
                      ¿Deseas ajustar alguna calificación?
                    </h2>
                    <p className="text-blue-100 text-sm">Dime qué consideras que no quedó bien calificado y lo re-evaluaré con el audio.</p>
                    <textarea 
                      value={feedback} 
                      onChange={(e) => setFeedback(e.target.value)} 
                      className="w-full bg-blue-500/50 border border-white/20 p-4 rounded-2xl text-white placeholder:text-blue-200 focus:outline-none focus:ring-2 focus:ring-white/50 transition-all text-sm" 
                      placeholder="Ej: En el punto de Inversión calificaste NO, pero el asesor sí lo mencionó en el minuto 3:20..." 
                      rows={3} 
                    />
                    <button 
                      onClick={handleRefine} 
                      disabled={refining || !feedback} 
                      className={`px-8 py-3 rounded-xl font-bold bg-white text-blue-600 hover:bg-blue-50 transition-all shadow-lg ${refining ? 'opacity-50' : ''}`}
                    >
                      {refining ? "Re-evaluando audio..." : "Refinar Resultados"}
                    </button>
                  </div>

                  <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 space-y-6">
                    <h2 className="font-bold text-2xl text-slate-800 flex items-center gap-2">
                       Consultas sobre el Audio
                    </h2>
                    <div className="space-y-4 h-[400px] overflow-y-auto border border-slate-50 p-6 rounded-2xl bg-slate-50/30 custom-scrollbar">
                      {chatHistory.length === 0 && (
                        <div className="h-full flex flex-col items-center justify-center text-slate-400 gap-2 opacity-50">
                          <BrainCircuit size={48} />
                          <p className="text-sm font-medium">Pregúntame cualquier detalle de la llamada</p>
                        </div>
                      )}
                      {chatHistory.map((h, i) => (
                        <motion.div 
                          key={i} 
                          initial={{ opacity: 0, x: -10 }} 
                          animate={{ opacity: 1, x: 0 }}
                          className="space-y-2 bg-white p-4 rounded-2xl shadow-sm border border-slate-100"
                        >
                          <p className="font-bold text-emerald-600 text-xs flex items-center gap-2">
                            <Users size={14} />
                            USUARIO: {h.question}
                          </p>
                          <div className="text-slate-700 text-sm leading-relaxed pl-5 border-l-2 border-emerald-100">
                             {h.answer}
                          </div>
                        </motion.div>
                      ))}
                    </div>
                    <div className="flex gap-2 p-2 bg-slate-100 rounded-2xl">
                      <input 
                        type="text" 
                        value={chatInput} 
                        onChange={(e) => setChatInput(e.target.value)} 
                        onKeyDown={(e) => e.key === 'Enter' && handleChat()}
                        className="flex-1 bg-transparent px-4 py-3 text-sm focus:outline-none focus:ring-0" 
                        placeholder="Ej: ¿Qué objeción puso el cliente con el precio?" 
                      />
                      <button 
                        onClick={handleChat} 
                        disabled={chatLoading || !chatInput} 
                        className={`bg-emerald-600 text-white px-6 py-3 rounded-xl font-bold transition-all ${chatLoading || !chatInput ? 'opacity-50' : 'hover:bg-emerald-700 shadow-md animate-in slide-in-from-right-2'}`}
                      >
                        {chatLoading ? "..." : "Consultar"}
                      </button>
                    </div>
                  </div>
                </div>
              )}
        </motion.div>
      </div>
    </div>
  );
}
